# Form Swipper
## Ejemplo de implementación
### Directorios
```bash
Folder
├── formSwipper.css
├── formSwipper.js
├── myFile.js
├── myStyle.css
└── index.html
```
### index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Swipper</title>
    <link rel="stylesheet" href="./formSwipper.css">
    <link rel="stylesheet" href="./myStyle.css">
</head>
<body>

    <div class="formSwipperContainer">
        <form class="formSwipper" id="exampleForm">
            <section>
                <div class="formPage">
                    <input type="radio" id="page-1" class="eventCallback">
                    <label for="page-1">Click me for validate</label>
                </div>
                <div class="formPage">
                    <input type="radio" id="page-2" class="eventCallback">
                    <label for="page-2">Click me for validate</label>
                </div>
                <div class="formPage">
                    <input type="radio" id="page-3" class="eventCallback">
                    <label for="page-3">Click me for validate</label>
                </div>
                <div class="formPage">
                    <input type="radio" id="page-4" class="eventCallback">
                    <label for="page-4">Click me for validate</label>
                </div>
            </section>
        </form>
    </div>

    <script type="module" src="./formSwipper.js"></script>
    <script type="module" src="./myFile.js"></script>
</body>
</html>
```
### myStyle.css
```css
.formSwipperContainer {
    width: 90%;
    max-width: 450px;
    margin: auto;
    margin-top: 5rem;
}
.formSwipper {
    min-height: 10vh
}
```
### myFile.js
```js
import { FormSwipper, FormHandler } from "./formSwipper.js";

var myFormSwipperConfig = {
    parentElementId: 'exampleForm',
    pagesClass: 'formPage',
    text: {
        next: 'Next',  
        back: 'Back', 
        submit: 'Send' 
    },
    submitCallback: myAlert
};

function myAlert(event) {
    event.preventDefault();
    alert('Submit successfully');
}

var fs = new FormSwipper(myFormSwipperConfig);



// En este ejemplo, se crea es una clase que gestiona todas las páginas,
// sin embargo, se recomienda utilizar una clase por cada página.

class MyPagesForms extends FormHandler{
    constructor(formSwipper){
        super(formSwipper);
        this.elements = document.getElementsByClassName('eventCallback');
        this.init();
    }
    init(){
        this.listener();
    }
    listener(){
        for(let i = 0; i < this.elements.length; i++){
            this.elements[i].addEventListener('click', this.callBack.bind(this) )
        }
    }
    callBack(){
        // This.form -> Atributo heredado de FormHandler
        this.form.nextBtnEnabled(true);
    }
}

var formHandler = new MyPagesForms(fs);
```